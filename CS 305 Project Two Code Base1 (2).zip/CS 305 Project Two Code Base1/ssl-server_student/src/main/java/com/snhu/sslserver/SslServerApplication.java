package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}
}

//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";

@RestController
class CheckSumController {
	@GetMapping("/checksum")
	public String getChecksum() {
		
		String data = "Hello Artemis Financial!";
		
		String checksum = generateChecksum(data);
		
		return "<h1>Checksum Information</h1>" +
			"<p>Data: " + data + "</p>" + 
			"<p>Algorithim: SHA-256</p>" + 
			"<p>Checksum: " + checksum + "</p>";
	}
	
	private String generateChecksum(String input) {
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			
			byte[] hashInBytes = md.digest(input.getBytes());
			
			return bytesToHex(hashInBytes);
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException("Error generating checksum", e);
		}
	}

	private String bytesToHex(byte[] bytes) {
		StringBuilder hexString = new StringBuilder();
		for(byte b : bytes) {
			String hex = Integer.toHexString(0xff & b);
			if (hex.length() == 1) hexString.append('0');
			hexString.append(hex);
		}
		return hexString.toString();
	}
}

	

